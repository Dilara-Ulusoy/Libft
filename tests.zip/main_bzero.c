
#include <strings.h>
#include <stdio.h>
int main()
{
   char x[] = "Hello";
   printf("Before ft_bzero: %s\n", x);
   ft_bzero(x, 5);
   bzero(x, 5);
   printf("After ft_bzero: %s\n", x); // Print x after erasing first 5 bytes
   return 0; // Return from main function
}
