 #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include "libft.h"
 int main()
 {
    char first[] = "Hello";
    char *result;
    result = ft_calloc(6, sizeof(char));
    ft_memcpy(result, first, 5);

    printf("ft_calloc: %s\n", result);
    free(result);
    return 0;
 }