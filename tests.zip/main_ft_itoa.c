#include <stdio.h>
#include "libft.h"
int main()
{
    int num = 12345;
    char *str = ft_itoa(num);
    printf("%s\n", str);
    return 0;
}
