#include "libft.h"
#include <stdio.h>

int main(void)
{
    char *str = "Hello,World,This,Is,Sparta";
    char **result = ft_split(str, ',');
    int i = 0;
    if (result == NULL)
    {
        printf("Memory allocation failed.\n");
        return 1;
    }
    // Print the result
    while (result[i])
    {
        printf("%s\n", result[i]);
        free(result[i]); 
        i++;
    }
    free(result);
    return 0;
}
