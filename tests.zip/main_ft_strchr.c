
#include <stdio.h>
#include <string.h>
#include "libft.h"
int main()
{
    char str[] = "My name is Dilara-";
    printf("My function: %s\n", ft_strchr(str, 'a'));

    char str2[] = "My name is Dilara-";
    printf("Library function: %s", strchr(str2, 'a'));
    return 0;
}
