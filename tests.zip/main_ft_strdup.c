
#include <string.h>
#include <stdio.h>
#include "libft.h"
int main (void)
{
    char *str;
    char *str2;
    char *str3;
    str = "hi there";
    str2 = ft_strdup(str);
    str3 = strdup(str);
    printf("My function; %s\n", str2);
    printf("Library function; %s", str3);
}
