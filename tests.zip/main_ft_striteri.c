
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
#include "libft.h"

void func(unsigned int i, char *c)
{
    *c = *c - 32;
}

 int main()
{
    char str[10] = "dilara";
    printf("Result before my function applied: %s\n", str);
    ft_striteri(str, &func);
    printf("Result after my function applied: %s\n", str);
    return 0;
}
