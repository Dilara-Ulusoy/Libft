
#include <stdio.h>
#include <stdlib.h>
#include "libft.h"

int main() {

    char const *s1 = "Hello, ";
    char const *s2 = "world!";
    char *joinedStr = ft_strjoin(s1, s2);
    if (joinedStr) {
        printf("ft_strjoin: %s\n", joinedStr); // Should print "Hello, world!"
        free(joinedStr);
    } else {
        printf("Memory allocation failed for ft_strjoin.\n");
    }

    return 0;
}