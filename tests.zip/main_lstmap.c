#include "libft.h"

void	*add_one(void *n)
{
	int	*number;
	int	*new_number;

	number = (int *)n;
	new_number = (int *)malloc(sizeof(int));
	if (!new_number)
		return (NULL);
	*new_number = *number + 1;
	return (new_number);
}

void	del(void *content)
{
	free(content);
}

int main() {
	t_list *list;
	t_list *new_list;
	int *number;
	int *new_number;

	number = (int *)malloc(sizeof(int));
	if (!number)
		return (0);
	*number = 1;
	list = ft_lstnew(number);
	if (!list)
	{
		free(number);
		return (0);
	}
	new_list = ft_lstmap(list, add_one, del);
	if (!new_list)
	{
		ft_lstclear(&list, del);
		return (0);
	}
	while (new_list)
	{
		new_number = (int *)new_list->content;
		printf("%d\n", *new_number);
		new_list = new_list->next;
	}
	ft_lstclear(&list, del);
	ft_lstclear(&new_list, del);
	return 0;
}