
#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include "libft.h"
int main()
{
    char str[] = "My name is Dilara-";
    printf("My function: %s\n", ft_memchr(str, 'a',5));

    char str2[] = "My name is Dilara-";
    printf("Library function: %s", memchr(str2, 'a', 5));
    return 0;
}