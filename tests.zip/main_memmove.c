
#include <stdio.h>
#include <string.h>
#include "libft.h"
int main() {
    char dest[] = "Hello World!";

    printf("Before ft_memmove string: %s\n", dest);
    ft_memmove(dest, dest+2 , 9);
    printf("After ft_memmove string: %s\n\n", dest);;
    
    char dest1[] = "Hello World!";
    
    printf("Before library memmove string: %s\n", dest1);
    memmove(dest1, dest1+2 , 9);
    printf("After library memmove string: %s\n\n", dest1);;

    return 0;
}