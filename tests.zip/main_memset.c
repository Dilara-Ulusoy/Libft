
#include <stdio.h>
#include "libft.h"
int main()
{
   char str[40] = "This is an example sentence";
   printf("Normal String = %s\n\n", str);
   ft_memset(str, '!', 5);
   printf("String after memset =  %s\n",str);
   return 0;
}
 