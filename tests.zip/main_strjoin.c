
#include <stdio.h>
#include <stdlib.h>
#include "libft.h"
int main() {
    char *strs[] = {"Apple", "Orange", "Plum", "Banana"};
    char *sep = "|";
    char *result = ft_strjoin(strs, sep);
    printf("%s\n", result);
    free(result);
    return 0;
}