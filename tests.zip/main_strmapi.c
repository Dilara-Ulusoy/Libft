
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "libft.h"

 char func(unsigned int i, char c)
 {
     return c - 32;
}

int main()
 {
     char str[10] = "dilara";
     printf("Result before my function applied: %s\n", str);
     char *result = ft_strmapi(str, func);
     printf("Result after my function applied: %s\n", result);
     free(result);
     return 0;
 }
