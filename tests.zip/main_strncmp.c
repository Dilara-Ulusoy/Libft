
#include <stdio.h>
#include <string.h>
#include "libft.h"

 int main()
 {
     char x[]= "Hello";
     char y[]= "Apple";
     printf("My function: %d\n",ft_strncmp(x,y, 5));
     
    char a[]= "Hello";
     char b[]= "Apple";
     printf("Library function: %d",strncmp(a,b, 5));
     
 }
 