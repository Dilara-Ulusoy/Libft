#include <stdio.h>
#include <string.h>
#include "libft.h"
int main()
{
    char str1[] = "My name is Dilara";
    printf("String 1: %s\n", ft_strrchr(str1, 'a'));
    
    char str2[] = "My name is Dilara";
    printf("String 2: %s",  strrchr(str2, 'a'));
    return 0;
}