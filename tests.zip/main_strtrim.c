
 #include <string.h>
 #include <stdlib.h>
 #include <stdio.h>
#include "libft.h"
 
 int main(void)
 {
 char str1[] = "---,Hello,,--";
    char trim1[] = "-,";
    printf("%s\n", ft_strtrim(str1, trim1));
     
    char str2[] = "---,Hello,,--";
    printf("If set is an empty string: %s\n", ft_strtrim(str2, ""));

    char str3[] = "--lll-,Hello,,ll--";
    char trim3[] = "-l,";
    printf("%s\n", ft_strtrim(str3, trim3));
 }
 